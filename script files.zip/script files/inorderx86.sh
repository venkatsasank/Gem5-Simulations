#!/bin/sh

#bitcount

./build/X86/gem5.opt -d ~results/bitcount/2 ./configs/example/se.py --ruby -c automotive/bitcount/bitcnts --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=64kB --l1d_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10

./build/X86/gem5.opt -d ~results/bitcount/1 ./configs/example/se.py --ruby -c automotive/bitcount/bitcnts --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=32kB --l1d_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10

#dijkstra

./build/X86/gem5.opt -d ~results/dijkstra/1 ./configs/example/se.py --ruby -c network/dijkstra/dijkstra_small --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=32kB --l1d_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10 -o network/dijkstra/input.dat

./build/X86/gem5.opt -d ~results/dijkstra/2 ./configs/example/se.py --ruby -c network/dijkstra/dijkstra_small --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=64kB --l1d_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10 -o network/dijkstra/input.dat

#qsort

./build/X86/gem5.opt -d ~results/qsortnew/2 ./configs/example/se.py --ruby -c automotive/qsort/qsort_large --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=64kB --l1d_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10 -o automotive/qsort/input_large.dat

./build/X86/gem5.opt -d ~results/qsortnew/1 ./configs/example/se.py --ruby -c automotive/qsort/qsort_large --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=32kB --l1d_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10 -o automotive/qsort/input_large.dat

#susan

./build/X86/gem5.opt -d ~results/susan/1 ./configs/example/se.py --ruby -c automotive/susan/susan --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=32kB --l1d_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10 -o automotive/susan/"input_small.pgm >output.pgm -s"

./build/X86/gem5.opt -d ~results/susan/2 ./configs/example/se.py --ruby -c automotive/susan/susan --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=64kB --l1d_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10 -o automotive/susan/"input_small.pgm >output.pgm -s"

#patricia

./build/X86/gem5.opt -d ~results/patricia/1 ./configs/example/se.py --ruby -c network/patricia/patricia --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=32kB --l1d_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10 -o network/patricia/small.udp

./build/X86/gem5.opt -d ~results/patricia/2 ./configs/example/se.py --ruby -c network/patricia/patricia --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=64kB --l1d_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10 -o network/patricia/small.udp

#basicmath

./build/X86/gem5.opt -d ~results/bm/1 ./configs/example/se.py --ruby -c automotive/basicmath/basicmath_small --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=32kB --l1d_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10


./build/X86/gem5.opt -d ~results/bm/2 ./configs/example/se.py --ruby -c automotive/basicmath/basicmath_small --cpu-type=MinorCPU --num-cpus=1 --caches --l2cache --l1i_size=64kB --l1d_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10



