#!/bin/sh

#bitcount

./build/X86/gem5.opt -d ~/bitcount ./configs/example/se.py --ruby -c ./automotive/bitcount/bitcnts --cpu-type=DerivO3CPU --caches --l2cache --l1d_size=32kB --l1i_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --num-cpus=1 

./build/X86/gem5.opt -d ~/bitcount1 ./configs/example/se.py --ruby -c ./automotive/bitcount/bitcnts --cpu-type=DerivO3CPU --caches --l2cache --l1d_size=64kB --l1i_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --num-cpus=1 

#dijkstra

./build/X86/gem5.opt -d ~/dijkstra ./configs/example/se.py --ruby -c ./network/dijkstra/dijkstra_small --cpu-type=DerivO3CPU --caches --l2cache --l1d_size=32kB --l1i_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --num-cpus=1 -o ./network/dijkstra/input.dat 

./build/X86/gem5.opt -d ~/dijkstra1 ./configs/example/se.py --ruby -c ./network/dijkstra/dijkstra_small --cpu-type=DerivO3CPU --caches --l2cache --l1d_size=64kB --l1i_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --num-cpus=1 -o ./network/dijkstra/input.dat 

#basicmath

./build/X86/gem5.opt -d ~/basicmath ./configs/example/se.py --ruby -c ./automotive/basicmath/basicmath_small --cpu-type=DerivO3CPU --caches --l2cache --l1d_size=32kB --l1i_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --num-cpus=1 

./build/X86/gem5.opt -d ~/basicmath1 ./configs/example/se.py --ruby -c ./automotive/basicmath/basicmath_small --cpu-type=DerivO3CPU --caches --l2cache --l1d_size=64kB --l1i_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --num-cpus=1

#qsort

./build/X86/gem5.opt -d ~/qsort ./configs/example/se.py --ruby -c ./automotive/qsort/qsort_large --cpu-type=DerivO3CPU --caches --l2cache --l1d_size=32kB --l1i_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --num-cpus=1 -o ./automotive/qsort/input_large.dat

./build/X86/gem5.opt -d ~/qsort1 ./configs/example/se.py --ruby -c ./automotive/qsort/qsort_large --cpu-type=DerivO3CPU --caches --l2cache --l1d_size=64kB --l1i_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --num-cpus=1 -o ./automotive/qsort/input_large.dat

#patricia

./build/X86/gem5.opt -d ~/patricia ./configs/example/se.py --ruby -c ./network/patricia/patricia --cpu-type=DerivO3CPU --caches --l2cache --l1d_size=32kB --l1i_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --num-cpus=1 -o ./network/patricia/small.udp

./build/X86/gem5.opt -d ~/patricia1 ./configs/example/se.py --ruby -c ./network/patricia/patricia --cpu-type=DerivO3CPU --caches --l2cache --l1d_size=64kB --l1i_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --num-cpus=1 -o ./network/patricia/small.udp

#susan

./build/X86/gem5.opt -d ~/susan ./configs/example/se.py -c ./automotive/susan/susan --cpu-type=DerivO3CPU --num-cpus=1 --caches --l2cache --l1i_size=32kB --l1d_size=32kB --l2_size=512kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10 -o susan/"input_small.pgm >output.pgm -s"

./build/X86/gem5.opt -d ~/susan1 ./configs/example/se.py -c ./automotive/susan/susan --cpu-type=DerivO3CPU --num-cpus=1 --caches --l2cache --l1i_size=64kB --l1d_size=64kB --l2_size=1MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=8 --cacheline_size=64 --options=10 -o susan/"input_small.pgm >output.pgm -s"
